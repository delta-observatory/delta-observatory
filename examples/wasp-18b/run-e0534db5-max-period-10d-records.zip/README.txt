Delta Observatory evidence export: run e0534db5-b3c5-47c2-bd47-b974916e6773

Exported by client richard (person).
API 0.1.0, contracts from database commit 00913dda1c67d56a8fcd29321f6f4b309204faad.
manifest.json follows contract export/1. It lists every other file with its size and SHA-256.
The same request on the same stored records gives the same bytes. The manifest holds no request time.

Files:
  run.json or runs.json   run parameters, method version, jobs, result documents, and software versions
  candidate.json          candidate with resolved evidence, assessments, decisions, notes, and actors
  records.json            research records that refer to the run
  observations.json       observation identifiers, file SHA-256, time conventions, and header values
  measurements.json/.csv  stored measurements with units, uncertainty, and quality flags
  artifacts.json          artifact identifiers, sizes, and SHA-256
  methods.json            method descriptions, parameter schemas, and scientific status
  artifacts/<id>/<file>   stored artifact bytes, when artifacts=all

Measurements come from worker methods. Model judgments are decision records. Evidence status and identity
status come from assessment records. These stay separate. A decision score is not an uncertainty.
Artifacts: none. Withheld: nothing.

Limitations:
  - tess-bls v1: Provisional. Guided recovery of two known planets in TESS sector 2 only. Depth accuracy, completeness, and false-alarm rates are not validated. Trend removal changes transit depths.
  - External files in the evidence are listed by URI, SHA-256, and size. The export does not include them. An external file is a proposal, not platform evidence.
  - Measurements, model judgments, evidence statuses, and identity statuses are separate records. A decision score is a judgment, not an uncertainty or a probability.

Check the export with backend/scripts/verify_export.py <file.zip>.
